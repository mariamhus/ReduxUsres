import React from 'react'

function NotFound() {
  return (
    <div>
      Not Found.
      Error 404!
    </div>
  )
}

export default NotFound
