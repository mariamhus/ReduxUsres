import { combineReducers } from "redux";
import ay7aga from "./userReduser/user.reduser"

export default combineReducers({user:ay7aga});